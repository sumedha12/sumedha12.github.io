var login_name;
var db = new PouchDB('kittens');
db.info().then(function (info) {
console.log(info);
})  
function login()
        {            
        login_name =    document.querySelector('#email').value;
        var login_pwd = document.querySelector('#password').value;                
        db.get(login_name).then(function (doc) {
            console.log(doc);
           //window.location.href = "http://localhost/entrepuener/data/newhtml2.html?"+login_name;    
            }).catch(function (err) {
            console.log(err);            
            });                                 
        }
    function register() 
    {
         var signup_name = document.querySelector('#email').value;
         var signup_pwd =  document.querySelector('#password').value;                                
           db.put({
              _id: signup_name,
              password:signup_pwd,              
              "Friends": {},
              "group": [[,,,],[,,,],[,,,],[,,,],[,,,],[,,,],[,,,],[,,,],[,,,],[,,,],],
              "glen":0,
              "length":0,
              "Date"     : "5/4/13",
              "nine"     : "Busy",
              "ten"      : "Busy",
              "eleven"   : "Busy",
              "twelve"   : "Busy",
              "Thirteen" : "Busy",
              "Fourteen" : "Busy",
              "Fifteen"  : "Busy",
                }).then(function (response) {
        console.log(response);         
        alert("CONGRATS! REGISTERED. PLEASE CONTINUE TO LOGIN")
            }).catch(function (err) {
        console.log(err);
            });      
    }    
function next()
{
    var x = location.search;
    var x = x.replace("?", "");     
    alert(x);
    window.location.href = "http://localhost/entrepuener/data/newhtml3.html?"+x;    
}
    function myfun() 
    {
        var fname = document.querySelector('#fname').value;  
        var x = location.search;
        var x = x.replace("?", "");
        function myDeltaFunction(doc) {
            var len = doc.length;
            alert(len);
            doc.Friends[""+len+""] =fname;                                            
            doc.length = len+1;                
            $(".well").append("<button> "+fname+" </button> <br><br>");          
            return doc;
            console.log(doc);
        }
        db.upsert(x, myDeltaFunction).then(function () {
        alert("success");
        }).catch(function (err) { 
        alert("notsuccess");        
})
}
function myfun1() 
{
var x = location.search;
var x = x.replace("?", "");     
db.get(x).then(function (doc) {
    var len = doc.length;       
    var i;
    for(i=0;i<len;i++)
    $(".well").append("<button> "+doc.Friends[i]+" </button> <br><br>");          
    return doc;
}).catch(function (err) {
  console.log(err);
});  
}
function hello()
      {
        var x = location.search;
        var x = x.replace("?", "");             
        var nine = document.getElementById("nine").innerHTML;
        var ten = document.getElementById("ten").innerHTML;
        var eleven = document.getElementById("eleven").innerHTML;
        var twelve = document.getElementById("twelve").innerHTML;
        var thirteen = document.getElementById("thirteen").innerHTML;
        var fourteen = document.getElementById("fourteen").innerHTML;      
        function myDeltaFunction(doc) {                 
            doc.nine = nine;       
            doc.ten = ten;       
            doc.eleven = eleven;       
            doc.twelve = twelve;       
            doc.thirteen = thirteen;       
            doc.fourteen = fourteen;                   
            alert("SCHEDULE UPDATED");
            return doc;
            console.log(doc);
        }
        db.upsert(x, myDeltaFunction).then(function () {
        alert("success");
          }).catch(function (err) {
          alert("notsuccess")        
})
}
function myfun3() 
    {
    var x = location.search;
    var x = x.replace("?", "");     
    db.get(x).then(function (doc) {
    var len = doc.length;       
    var i;
    for(i=0;i<len;i++)
    $(".well").append("<button button class=newbutton onClick = time() name=newbutton id ="+i+"> "+doc.Friends[i]+" </button> <br><br>");          
    return doc;
    }).catch(function (err) {
  console.log(err);});  
    }    
function hello2()
    {        
    var x = location.search;
    var x = x.replace("?", "");     
    alert(x);
    alert(x);
    window.location.href = "http://localhost/entrepuener/data/allfriends.html?"+x;                        
    }    
function hello1()
    {        
    var x = location.search;
    var x = x.replace("?", "");     
    alert(x);    
    window.location.href = "http://localhost/entrepuener/data/newhtml4.html?"+x;                        
    }    
function schedule()
    {        
     var x = location.search;
     var x = x.replace("?", "");     
     db.get(x).then(function (doc) {
     document.getElementById("nine").innerHTML= doc.nine;
     document.getElementById("ten").innerHTML = doc.ten;
     document.getElementById("eleven").innerHTML = doc.eleven;
     document.getElementById("twelve").innerHTML = doc.twelve;
     document.getElementById("thirteen").innerHTML =doc.Thirteen;
     document.getElementById("fourteen").innerHTML =doc.Fourteen;       
     return doc;
    }).catch(function (err) {
     console.log(err);
});}
    function timealign()
    {
     var x = location.search;
     x = x.replace("?", ""); 
     var res = x.split("%20");
      db.get(res[1]).then(function (doc) {      
        document.getElementById("nine").innerHTML= doc.nine;
        document.getElementById("ten").innerHTML = doc.ten;
        document.getElementById("eleven").innerHTML = doc.eleven;
        document.getElementById("twelve").innerHTML = doc.twelve;
        document.getElementById("thirteen").innerHTML =doc.Thirteen;
        document.getElementById("fourteen").innerHTML =doc.Fourteen;       
       }).catch(function (err) {
     console.log(err);});
 
 db.get(res[2]).then(function (doc) {
        document.getElementById("nine").innerHTML= doc.nine;
        document.getElementById("ten").innerHTML = doc.ten;
        document.getElementById("eleven").innerHTML = doc.eleven;
        document.getElementById("twelve").innerHTML = doc.twelve;
        document.getElementById("thirteen").innerHTML =doc.Thirteen;
        document.getElementById("fourteen").innerHTML =doc.Fourteen;       
       }).catch(function (err) {
     console.log(err);});
    }
    function time()
    {
    var x = location.search;
    var x = x.replace("?", "");     
    //alert(x);
    $("button").click(function() {
    var id=this.id;
    var friend = document.getElementById(id).innerHTML;
    //alert(friend);
    window.location.href = "http://localhost/entrepuener/data/newhtml5.html?"+friend+x;    
        });    
    }
function group_page()
{
var x = location.search;
var x = x.replace("?", "");     
window.location.href = "http://localhost/entrepuener/data/groups.html?"+x;        
}
function group()
{
var x = location.search;
var x = x.replace("?", "");     
db.get(x).then(function (doc) {
   var len = doc.length;       
   var i;
   txt = "aa";
   for(i=0;i<len;i++)  
   {                
    $('.well').append('<label class="checkbox-inline"><input type="checkbox" name="user" value='+doc.Friends[i]+'>'+doc.Friends[i]+'</label>');            
   }
    var glen = doc.glen;
    alert(glen);    
    for(i=0;i<glen;i++)
    {
    var node = document.createElement("li");
        var textnode = document.createTextNode(doc.group[0][i]);
        node.appendChild(textnode);
        document.getElementById("demolist").appendChild(node);       
        //$("ul").append("<li><a href>"+doc.group[0][i]+"</a></li>");     
    }
    return doc;
}).catch(function (err) {
  console.log(err);
});  
}
function group_mem()
{
var x = location.search;
var x = x.replace("?", "");     

db.get(x).then(function (doc) {
var groupname = document.getElementByID(menu1).value;  
var groupuser = [];
var no;
for(var i=0;i<doc.glen;i++)
    {
    if(doc.group[i][0]==groupname)
        {
        no=i;   
        }        
}
var len = doc.group[no].length;
for(var i=1;i<len;i++)
{
    groupuser.push(doc.group[no][i]);
}

}).catch(function (err) {
  console.log(err);
});  
}
function addgroup()
{          
var x = location.search;
var x = x.replace("?", "");          
var groupname = document.querySelector('#fname').value;  
var groupuser = [];
$.each($("input[name='user']:checked"), function(){            
   groupuser.push($(this).val());
   });      
    function myDeltaFunction(doc) 
        {            
        var glen = doc.glen;        
        doc.glen = doc.glen + 1;        
        doc.group[glen][0] =groupname;                                                                 
        
        $("ul").append("<li><a>"+groupname+"</a></li>");
        var len = groupuser.length;
        alert(len);
        for(var i=1;i<=len;i++)
        {
         doc.group[glen][i] = groupuser[i-1];                                                                                 
        }
        return doc;
        console.log(doc);
        }   
        db.upsert(x, myDeltaFunction).then(function () {            
            alert("success");            
        }).catch(function (err) { 
        alert("notsuccess");
          console.log(err);
   })
}
$( document ).ready(function() {
 $("ul li a").click(function(){
    alert("AA");
    var selText = $(this).text();
  //$(this).parents('.btn-group').find('.dropdown-toggle').html(selText+'<span class="caret"></span>');
document.getElementById("menu1").innerHTML=$(this).text();        
});
});
